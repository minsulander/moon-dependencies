#ifndef __APP_TYPES_H
#define __APP_TYPES_H

typedef unsigned int AppTime;

#endif
