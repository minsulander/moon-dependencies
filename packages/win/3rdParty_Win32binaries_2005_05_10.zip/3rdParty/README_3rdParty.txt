README_3rdParty.txt - Mike Weiblen http://mew.cx/ 2005-05-10

This is a package of prebuilt 3rd party dependency libraries for use with
the Open Scene Graph http://openscenegraph.org/

These binaries were built using Microsoft VisualStudio 2003 v7.1 from the
sources listed below, with minor modifications to the makefiles/projectfiles
for consistent use of the multi-threaded DLL version of the Microsoft runtime
libraries.  It is not known whether these binaries will work with anything
other than VS7.1 2003.

Upstream archives:

http://prdownloads.sourceforge.net/freetype/ft219.zip
ftp://ftp.remotesensing.org/pub/gdal/gdal126.zip
http://www.xmission.com/~nate/glut/glut-3.7.6-src.zip
ftp://ftp.simtel.net/pub/simtelnet/msdos/graphics/jpegsr6.zip
http://prdownloads.sourceforge.net/libungif/libungif-4.1.3.tar.gz
ftp://swrinde.nde.swri.edu/pub/png/src/lpng128.zip
ftp://ftp.remotesensing.org/pub/proj/proj-4.4.9.zip
ftp://ftp.remotesensing.org/pub/libtiff/tiff-3.7.2.zip
http://www.zlib.net/zlib122.zip

