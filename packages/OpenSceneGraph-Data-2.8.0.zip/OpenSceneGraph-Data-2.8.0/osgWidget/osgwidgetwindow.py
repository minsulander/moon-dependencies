# $Id: osgwidgetwindow.py 2 2008-01-24 16:11:26Z cubicool $

w = osgwidget.newWindow("nope")
