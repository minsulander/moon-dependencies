#ifndef UNITTEST_TESTSUITE_H
#define UNITTEST_TESTSUITE_H

namespace UnitTestSuite {

    inline char const* GetSuiteName ()
    {
        return "DefaultSuite";
    }

}

#endif

