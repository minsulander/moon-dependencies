/*
** Lua binding: tclass
** Generated automatically by tolua++-1.0.4 on Sat Apr  2 01:00:39 2005.
*/

/* Exported function */
TOLUA_API int tolua_tclass_open (lua_State* tolua_S);

